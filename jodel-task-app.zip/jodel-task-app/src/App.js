import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { addTask, removeTask } from "./redux/taskSlice";
import "./App.css";

export default function App() {
  // Local state: tracks what the user types in the input box
  const [inputText, setInputText] = useState("");

  // dispatch lets us send actions to the Redux store
  const dispatch = useDispatch();

  // useSelector reads the task list from the Redux store
  const tasks = useSelector((state) => state.tasks.list);

  // Called when the user clicks "Add Task"
  const handleAdd = () => {
    if (!inputText.trim()) return; // Don't add empty tasks
    dispatch(addTask(inputText));  // Send task to Redux
    setInputText("");              // Clear the input field
  };

  // Called when the user clicks the ✕ button on a task
  const handleDelete = (index) => {
    dispatch(removeTask(index));
  };

  // Allow pressing Enter to add a task
  const handleKeyDown = (e) => {
    if (e.key === "Enter") handleAdd();
  };

  return (
    <div className="app-wrapper">
      <div className="card">
        {/* Header */}
        <h1 className="app-title">📋 My Task List</h1>
        <p className="app-subtitle">Stay organized. One task at a time.</p>

        {/* Input Row */}
        <div className="input-row">
          <input
            className="task-input"
            type="text"
            placeholder="Type a task..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <button className="add-btn" onClick={handleAdd}>
            Add
          </button>
        </div>

        {/* Task List */}
        <ul className="task-list">
          {tasks.length === 0 && (
            <p className="empty-msg">No tasks yet. Add one above!</p>
          )}

          {tasks.map((taskText, index) => (
            <li className="task-item" key={index}>
              <span className="task-text">{taskText}</span>
              <button
                className="delete-btn"
                onClick={() => handleDelete(index)}
                title="Remove task"
              >
                ✕
              </button>
            </li>
          ))}
        </ul>
      </div>

      {/* Footer */}
      <p className="footer">
        Made by <span>Jodel Labios</span>
      </p>
    </div>
  );
}
